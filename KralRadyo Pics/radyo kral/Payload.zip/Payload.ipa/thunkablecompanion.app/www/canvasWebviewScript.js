const canvasWebviewScript = `

const postMessageToApp = function(message) {
  window.ReactNativeWebView.postMessage(message);
}

const loadedAssetKeys = [];
const errorAssetKeys = [];
const idToPhaserObject = {};
const idToHiddenPhaserObject = {};
const drawingInfoObject = {enabled: false, color: 0x000000, radius: 10};
const boundaryCollisionCategory = 1;
const collideAllCollisionCategory = 2;
const passesThroughCollisionCategory = 4;
const defaultCollisionGroup = 0;
const defaultCollisionMask = Math.pow(2,32) -1;
const passThroughCollisionGroup = -1;
const XY_SCALE_FACTOR = 4;

let collidingIds = {}; // [collidee1] : [id1, id2] collidee1 has the smaller id
let wallCollisionIds = {}; // [spriteId] : ['LEFT', 'TOP']
let hasCreateRun = false;
let phaserGame;
// assetKeysToFiles and spriteIdToSpriteInfo come from injected js

let canvas;
let context;
let image;

const preload = function() {
  phaserGame = this;
  let width = phaserGame.game.scale.width;
  let height = phaserGame.game.scale.height;
  canvas = phaserGame.textures.createCanvas('canvas', width, height);
  context = canvas.getContext('2d');
  image = phaserGame.add.image(width/2, height/2, 'canvas');
  this.textures.on('onload', key => {
    loadedAssetKeys.push(key);
    setupSprites(this);
  });
  this.textures.on('onerror', key => {
    errorAssetKeys.push(key);
    setupSprites(this);
  });
  for (const assetKey in assetKeysToFiles) {
    this.textures.addBase64(assetKey, 'data:image/png;base64,' + assetKeysToFiles[assetKey]);
  }
}

const createNewSprite = ({ spriteId, parentId, picture, height, width, x, y, angle, fixedRotation, isStatic, isDraggable, passesThrough, ignoreGravity, bounce, leaveTrail, trailColor, trailWidth}) => {
  const imageHeight = phaserGame.textures.get(picture).getSourceImage().height;
  const imageWidth = phaserGame.textures.get(picture).getSourceImage().width;
  const phaserSprite = phaserGame.matter.add.image(x, y, picture, null, {ignorePointer: !isDraggable});
  idToPhaserObject[spriteId] = phaserSprite;
  phaserSprite.thunkableId = spriteId;
  phaserSprite.thunkableParentId = parentId;
  phaserSprite.setScale(width / imageWidth, height / imageHeight);
  phaserSprite.setInteractive();
  phaserSprite.setFriction(0,0,0);
  phaserSprite.setStatic(isStatic);
  phaserSprite.setAngle(angle);
  phaserSprite.leaveTrail = leaveTrail;
  phaserSprite.trailColor = trailColor;
  phaserSprite.trailWidth = trailWidth;
  phaserSprite.lastX = undefined;
  phaserSprite.lastY = undefined;
  if (fixedRotation) {
    phaserSprite.setFixedRotation();
  }
  phaserSprite.on('pointerdown', function(pointer, gameObject) {
    // send message to parent
    const eventMessage = {type: "inputDown", id: spriteId, parentId: parentId};
    postMessageToApp(JSON.stringify(eventMessage));
  }, this);
  if (passesThrough) {
    phaserSprite.setCollisionGroup(passThroughCollisionGroup);
    phaserSprite.setCollisionCategory(passesThroughCollisionCategory);
    phaserSprite.setCollidesWith([boundaryCollisionCategory]);
  } else {
    phaserSprite.setCollisionCategory(collideAllCollisionCategory);
  }
  phaserSprite.setIgnoreGravity(!!ignoreGravity)
  phaserSprite.setBounce((bounce || 0) / 100);
  return phaserSprite;
}

const setupSprites = function(game) {
  if (!shouldSetupSprites()) return;
  game.matter.world.setBounds();
  for (const spriteId in spriteIdToSpriteInfo) {
    const spriteInfo = spriteIdToSpriteInfo[spriteId];
    const phaserSprite = createNewSprite({
      spriteId: spriteInfo.id,
      parentId: spriteInfo.ParentId,
      picture: spriteInfo.PictureSelection,
      height: spriteInfo.Height * XY_SCALE_FACTOR,
      width: spriteInfo.Width * XY_SCALE_FACTOR,
      x: spriteInfo.X * XY_SCALE_FACTOR,
      y: spriteInfo.Y * XY_SCALE_FACTOR,
      angle: spriteInfo.Angle,
      fixedRotation: spriteInfo.FixedRotation,
      isStatic: spriteInfo.IsStatic,
      isDraggable: spriteInfo.IsDraggable,
      passesThrough: spriteInfo.PassesThrough,
      ignoreGravity: spriteInfo.IgnoreGravity,
      bounce: spriteInfo.Bounce,
      leaveTrail: spriteInfo.LeaveTrail,
      trailColor: spriteInfo.TrailColor,
      trailWidth: spriteInfo.TrailWidth,
    });
  }

  game.input.on('pointerdown', function(pointer){
    const eventMessage = {type: "INPUT_DOWN", pointerId: pointer.id};
    postMessageToApp(JSON.stringify(eventMessage));
  });

  game.matter.add.pointerConstraint({ length: 1, stiffness: 0.6 });

  game.matter.world.on('dragstart', function(body) {
    body.gameObject.beforeDragRotation = body.gameObject.rotation;
  });

  game.matter.world.on('drag', function(body) {
    body.gameObject.setVelocity(0);
  });

  game.matter.world.on('dragend', function(body) {
    body.gameObject.setVelocity(0);
    body.gameObject.setAngularVelocity(0);
    body.gameObject.setRotation(body.gameObject.beforeDragRotation);
    const eventMessage = {type: "DROPPED", id: body.gameObject.thunkableId, parentId: body.gameObject.thunkableParentId};
    postMessageToApp(JSON.stringify(eventMessage));
  });

  const eventMessage = {type: "CANVAS_LOADS"};
  postMessageToApp(JSON.stringify(eventMessage));
}

const shouldSetupSprites = function() {
  return (hasCreateRun && Object.keys(assetKeysToFiles).length === loadedAssetKeys.length + errorAssetKeys.length);
}

const create = function() {
  hasCreateRun = true;
  createSlime(this);
  setupSprites(this);
}

const update = function() {
  // test all of the sprite to see which ones have collided
  const sortedIds = Object.keys(idToPhaserObject).sort();
  const newCollidingIds = {};
  for (let i = 0; i < sortedIds.length; i++) {
    const spriteId1 = sortedIds[i];
    const sprite1 = idToPhaserObject[spriteId1];
    handleSpriteTrail(sprite1);
    for (let k = i + 1; k < sortedIds.length; k++) {
      const spriteId2 = sortedIds[k];
      const sprite2 = idToPhaserObject[spriteId2];
      const distanceBetween = Phaser.Math.Distance.Between(sprite1.x, sprite1.y, sprite2.x, sprite2.y);
      // see if the sprites are close enough to be colliding
      if (distanceBetween < Math.sqrt( Math.pow( sprite1.height * sprite1.scaleY / 2 , 2) + Math.pow(sprite1.width * sprite1.scaleX / 2 , 2)) + Math.sqrt( Math.pow( sprite2.height * sprite2.scaleY / 2 , 2) + Math.pow(sprite2.width * sprite2.scaleX / 2 , 2)) ) {
        // more intensive check to see if the sprites are colliding
        if (doPolygonsIntersect(getCornerPointsForSprite(sprite1), getCornerPointsForSprite(sprite2))) {
          if (!newCollidingIds[spriteId1]) {
            newCollidingIds[spriteId1] = [];
          }
          if (newCollidingIds[spriteId1].indexOf(spriteId2) === -1) {
            newCollidingIds[spriteId1].push(spriteId2);
          }
          if (!collidingIds[spriteId1] || collidingIds[spriteId1].indexOf(spriteId2) === -1) {
            // two sprites are colliding with each other (and weren't previously colliding)
            const eventMessage = {
              type: "COLLIDE_SPRITE",
              collideeA: sprite1.thunkableId,
              collideeAParent: sprite1.thunkableParentId,
              collideeB: sprite2.thunkableId,
              collideeBParent: sprite2.thunkableParentId
            };
            postMessageToApp(JSON.stringify(eventMessage));
          }
        }
      }
    }
    // detect wall collisions
    const spriteCorners = getCornerPointsForSprite(sprite1);
    const collidedWalls = {};
    for (let k = 0; k < spriteCorners.length; k++) {
      if (spriteCorners[k].x <= 0) {
        collidedWalls['LEFT'] = true;
      }
      if (spriteCorners[k].y <= 0) {
        collidedWalls['TOP'] = true;
      }
      if (spriteCorners[k].x >= config.scale.width) {
        collidedWalls['RIGHT'] = true;
      }
      if (spriteCorners[k].y >= config.scale.height) {
        collidedWalls['BOTTOM'] = true;
      }
    }
    const collidedWallList = Object.keys(collidedWalls);
    if (!wallCollisionIds[spriteId1] && collidedWallList.length !== 0) {
      wallCollisionIds[spriteId1] = [];
    }
    for (let k = 0; k < collidedWallList.length; k++) {
      if (wallCollisionIds[spriteId1].indexOf(collidedWallList[k]) === -1) {
        const eventMessage = {
          type: "COLLIDE_EDGE",
          id: sprite1.thunkableId,
          parentId: sprite1.thunkableParentId,
          edge: collidedWallList[k]
        };
        postMessageToApp(JSON.stringify(eventMessage));
      }
    }
    wallCollisionIds[spriteId1] = collidedWallList;
  }
  collidingIds = newCollidingIds;

}

const getPhaserObjectById = function(id) {
  return idToPhaserObject[id];
}

const removePhaserObjectById = function(id) {
  delete idToPhaserObject[id];
}

const setHiddenPhaserObjectById = function(id, object) {
  idToHiddenPhaserObject[id] = object;
}

const getHiddenPhaserObjectById = function(id) {
  return idToHiddenPhaserObject[id];
}

const handleSpriteTrail = function(sprite) {
  if (sprite.leaveTrail) {
    if (sprite.lastX && sprite.lastY) {
      let color = sprite.trailColor;
      let radius = sprite.trailWidth/2;
      let oldX = sprite.lastX;
      let oldY = sprite.lastY;
      let newX = sprite.x;
      let newY = sprite.y;
      connectPoints(color, radius, oldX, oldY, newX, newY);
    } else {
      context.fillStyle = sprite.trailColor;
      fillCircle(sprite.x, sprite.y, sprite.trailWidth/2);
    }
    sprite.lastX = sprite.x;
    sprite.lastY = sprite.y;
  }
}

const createSlime = function(game) {

  game.input.on('pointerdown', function(pointer){
    if (drawingInfoObject.enabled) {
      context.fillStyle = drawingInfoObject.color;
      fillCircle(pointer.x, pointer.y, drawingInfoObject.radius);
    }
  });

  game.input.on('pointermove', function (pointer) {
    if (drawingInfoObject.enabled) {
      let color = drawingInfoObject.color;
      let radius = drawingInfoObject.radius;
      let oldX = pointer.prevPosition.x;
      let oldY = pointer.prevPosition.y;
      let newX = pointer.x;
      let newY = pointer.y;
      connectPoints(color, radius, oldX, oldY, newX, newY);
    }
  });
}

const connectPoints = function(color, radius, oldX, oldY, newX, newY) {
  oldX = Math.round(oldX);
  oldY = Math.round(oldY);
  newX = Math.round(newX);
  newY = Math.round(newY);
  let deltaX = Math.abs(newX - oldX);
  let deltaY = Math.abs(newY - oldY);

  let stepSize = 1;
  let incrementX = stepSize;
  if (newX < oldX) {
    incrementX *= -1;
  }
  let incrementY = stepSize;
  if (newY < oldY) {
    incrementY *= -1;
  }

  let currX = oldX;
  let currY = oldY;
  let numSteps;
  if (deltaX > deltaY) {
    numSteps = deltaX / stepSize;
    incrementY *= deltaY / deltaX;
  } else {
    numSteps = deltaY / stepSize;
    incrementX *= deltaX / deltaY;
  }
  context.fillStyle = color;
  for (let i = 0; i < numSteps; i += stepSize) {
    fillCircle(currX, currY, radius);
    currX += incrementX;
    currY += incrementY;
  }
}

const fillCircle = function(x, y, radius) {
  context.beginPath();
  context.arc(x, y, radius, 0, 2 * Math.PI, true);
  context.closePath();
  context.fill();
}

function getCornerPointsForSprite(sprite) {
  const height = sprite.height * sprite.scaleY;
  const width = sprite.width * sprite.scaleX;
  const points = [
    {x: sprite.x - width/2, y: sprite.y + height/2},
    {x: sprite.x + width/2, y: sprite.y + height/2},
    {x: sprite.x + width/2, y: sprite.y - height/2},
    {x: sprite.x - width/2, y: sprite.y - height/2},
  ];
  const rotatedPoints = points.map(point => ({
    x: ((point.x - sprite.x) * Math.cos(sprite.angle * Math.PI / 180 ) - (point.y - sprite.y) * Math.sin(sprite.angle * Math.PI / 180 )) + sprite.x,
    y: ((point.x - sprite.x) * Math.sin(sprite.angle * Math.PI / 180 ) + (point.y - sprite.y) * Math.cos(sprite.angle * Math.PI / 180 )) + sprite.y
  }));
  return rotatedPoints;
}

// from https://stackoverflow.com/questions/10962379/how-to-check-intersection-between-2-rotated-rectangles
/**
 * Helper function to determine whether there is an intersection between the two polygons described
 * by the lists of vertices. Uses the Separating Axis Theorem
 *
 * @param a an array of connected points [{x:, y:}, {x:, y:},...] that form a closed polygon
 * @param b an array of connected points [{x:, y:}, {x:, y:},...] that form a closed polygon
 * @return true if there is any intersection between the 2 polygons, false otherwise
 */
function doPolygonsIntersect (a, b) {
  var polygons = [a, b];
  var minA, maxA, projected, i, i1, j, minB, maxB;

  for (i = 0; i < polygons.length; i++) {

    // for each polygon, look at each edge of the polygon, and determine if it separates
    // the two shapes
    var polygon = polygons[i];
    for (i1 = 0; i1 < polygon.length; i1++) {

      // grab 2 vertices to create an edge
      var i2 = (i1 + 1) % polygon.length;
      var p1 = polygon[i1];
      var p2 = polygon[i2];

      // find the line perpendicular to this edge
      var normal = { x: p2.y - p1.y, y: p1.x - p2.x };

      minA = maxA = undefined;
      // for each vertex in the first shape, project it onto the line perpendicular to the edge
      // and keep track of the min and max of these values
      for (j = 0; j < a.length; j++) {
        projected = normal.x * a[j].x + normal.y * a[j].y;
        if (minA === undefined || projected < minA) {
          minA = projected;
        }
        if (maxA === undefined || projected > maxA) {
          maxA = projected;
        }
      }

      // for each vertex in the second shape, project it onto the line perpendicular to the edge
      // and keep track of the min and max of these values
      minB = maxB = undefined;
      for (j = 0; j < b.length; j++) {
        projected = normal.x * b[j].x + normal.y * b[j].y;
        if (minB === undefined || projected < minB) {
          minB = projected;
        }
        if (maxB === undefined || projected > maxB) {
          maxB = projected;
        }
      }

      // if there is no overlap between the projects, the edge we are looking at separates the two
      // polygons, and we know there is no overlap
      if (maxA < minB || maxB < minA) {
        return false;
      }
    }
  }
  return true;
};

`;

export default canvasWebviewScript;
